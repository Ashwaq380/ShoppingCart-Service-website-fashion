# ShoppingCartService

A Spring Boot application for managing shopping cart operations.